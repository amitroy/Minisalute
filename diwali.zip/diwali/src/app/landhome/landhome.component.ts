import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landhome',
  templateUrl: './landhome.component.html',
  styleUrls: ['./landhome.component.css']
})
export class LandhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
